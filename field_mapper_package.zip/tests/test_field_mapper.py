import os
import sys
import unittest

CURRENT_DIR = os.path.dirname(__file__)
SRC_DIR = os.path.join(CURRENT_DIR, "..", "src")
sys.path.insert(0, os.path.abspath(SRC_DIR))

from utils.field_mapper import to_storage_keys, to_model_keys

class TestFieldMapper(unittest.TestCase):
    def test_to_storage_keys_simple(self):
        data = {"ID":1,"Type":"client","Name":"Vu Le Anh","City":"Melbourne"}
        result = to_storage_keys(data)
        self.assertEqual(result["id"],1)
        self.assertEqual(result["type"],"client")
        self.assertEqual(result["name"],"Vu Le Anh")
        self.assertEqual(result["city"],"Melbourne")

    def test_to_storage_keys_nested(self):
        data={"ID":10,"Type":"client","Meta":{"CreatedBy":"tester","InnerID":99}}
        result=to_storage_keys(data)
        self.assertEqual(result["id"],10)
        self.assertEqual(result["type"],"client")
        self.assertIn("meta",result)
        self.assertIn("createdby",result["meta"])
        self.assertIn("innerid",result["meta"])

    def test_to_storage_keys_non_dict_passthrough(self):
        self.assertEqual(to_storage_keys(123),123)
        self.assertEqual(to_storage_keys("abc"),"abc")
        self.assertEqual(to_storage_keys(["A","B"]),["A","B"])

    def test_to_model_keys_simple(self):
        data={"id":5,"type":"flight","name":"Test Flight","city":"Sydney"}
        result=to_model_keys(data)
        self.assertIn("ID",result)
        self.assertIn("Type",result)
        self.assertEqual(result["ID"],5)
        self.assertEqual(result["Type"],"flight")
        self.assertIn("name",result)
        self.assertIn("city",result)

    def test_to_model_keys_nested(self):
        data={"id":1,"type":"client","meta":{"createdby":"tester","inner":{"id":99,"type":"airline"}}}
        result=to_model_keys(data)
        self.assertIn("ID",result)
        self.assertIn("Type",result)
        inner=result["meta"]["inner"]
        self.assertEqual(inner["ID"],99)
        self.assertEqual(inner["Type"],"airline")

    def test_to_model_keys_non_dict_passthrough(self):
        self.assertEqual(to_model_keys(123),123)
        self.assertEqual(to_model_keys("abc"),"abc")
        self.assertEqual(to_model_keys(["x","y"]),["x","y"])

    def test_round_trip_model_to_storage_and_back(self):
        original={"ID":42,"Type":"client","Name":"Vu","City":"HCM"}
        stored=to_storage_keys(original)
        restored=to_model_keys(stored)
        original_norm={k.lower():v for k,v in original.items()}
        restored_norm={k.lower():v for k,v in restored.items()}
        self.assertEqual(restored_norm,original_norm)

if __name__=="__main__":
    unittest.main(verbosity=2)
