
# utils/field_mapper.py

def to_storage_keys(data):
    if not isinstance(data, dict):
        return data
    result={}
    for k,v in data.items():
        nk = k.lower()
        if isinstance(v, dict):
            result[nk]=to_storage_keys(v)
        else:
            result[nk]=v
    return result

def to_model_keys(data):
    if not isinstance(data, dict):
        return data
    result={}
    for k,v in data.items():
        if k=="id":
            nk="ID"
        elif k=="type":
            nk="Type"
        else:
            nk=k
        if isinstance(v, dict):
            result[nk]=to_model_keys(v)
        else:
            result[nk]=v
    return result
