from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from pathlib import Path
import sys
import os

# ============ SETUP PATHS ============
BACKEND_DIR = Path(__file__).parent          # src/backend
SRC_DIR = BACKEND_DIR.parent                 # src
GUI_DIR = SRC_DIR / "gui"
RECORD_DIR = SRC_DIR / "record"

print("=" * 60)
print("SYSTEM PATHS CONFIGURATION")
print("=" * 60)
print(f"Backend directory: {BACKEND_DIR}")
print(f"Source directory: {SRC_DIR}")
print(f"GUI directory: {GUI_DIR} (exists: {GUI_DIR.exists()})")
print(f"Record directory: {RECORD_DIR} (exists: {RECORD_DIR.exists()})")
print("=" * 60)

# Đảm bảo project root (chứa thư mục src) có trong sys.path
PROJECT_ROOT = SRC_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Debug
print("Python search path:")
for i, path in enumerate(sys.path[:5]):
    print(f"  {i}. {path}")
print("  ...")
print("=" * 60)

# ============ FLASK APP ============
app = Flask(__name__, static_folder=str(GUI_DIR))
CORS(app)

# ============ DATA FILE ============
DATA_FILE = RECORD_DIR / "records.json"
print(f"Data file: {DATA_FILE.absolute()}")
print(f"Data file exists: {DATA_FILE.exists()}")

DATA_FILE.parent.mkdir(parents=True, exist_ok=True)

# ============ IMPORT STORAGE ============
from src.data.record_storage import RecordStorage  # dùng package src chuẩn

try:
    storage = RecordStorage(str(DATA_FILE))
    print(f"✓ Storage initialized with {len(storage.records)} records")
except Exception as e:
    print(f"✗ Error initializing storage: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("=" * 60)


# ============ ROUTES ============

@app.route('/')
def serve_gui():
    """Serve main Vue app"""
    if not GUI_DIR.exists():
        return jsonify({"error": "GUI directory not found"}), 404

    index_path = GUI_DIR / "index.html"
    if not index_path.exists():
        return jsonify({
            "error": "index.html not found",
            "gui_directory": str(GUI_DIR),
            "files_in_gui": [f.name for f in GUI_DIR.glob("*")]
        }), 404

    return send_from_directory(str(GUI_DIR), 'index.html')


@app.route('/<path:filename>')
def serve_static(filename):
    """Serve static assets"""
    if not GUI_DIR.exists():
        return jsonify({"error": "GUI directory not found"}), 404

    file_path = GUI_DIR / filename
    if file_path.exists() and file_path.is_file():
        return send_from_directory(str(GUI_DIR), filename)
    else:
        if filename.startswith('api/'):
            return jsonify({"error": "API endpoint not found"}), 404
        return send_from_directory(str(GUI_DIR), 'index.html')


@app.route('/api/')
def api_root():
    return jsonify({
        "message": "Record Management System API",
        "version": "1.0.0",
        "endpoints": {
            "clients": {
                "GET /api/clients": "Get all clients",
                "POST /api/clients": "Create new client",
                "GET /api/clients/<id>": "Get specific client",
                "PUT /api/clients/<id>": "Update client",
                "DELETE /api/clients/<id>": "Delete client"
            },
            "airlines": {
                "GET /api/airlines": "Get all airlines",
                "POST /api/airlines": "Create new airline",
                "GET /api/airlines/<id>": "Get specific airline",
                "PUT /api/airlines/<id>": "Update airline",
                "DELETE /api/airlines/<id>": "Delete airline"
            },
            "flights": {
                "GET /api/flights": "Get all flights",
                "POST /api/flights": "Create new flight",
                "GET /api/flights/<id>": "Get specific flight",
                "PUT /api/flights/<id>": "Update flight",
                "DELETE /api/flights/<id>": "Delete flight"
            },
            "utilities": {
                "GET /api/search": "Search records",
                "GET /api/stats": "Get system statistics",
                "GET /api/health": "Health check"
            }
        }
    })


# ================== CLIENTS ==================

@app.route('/api/clients', methods=['GET'])
def get_clients():
    try:
        clients = storage.read_all_records('client')
        return jsonify([c.to_dict() for c in clients])
    except Exception as e:
        return jsonify({"error": f"Failed to fetch clients: {str(e)}"}), 500


@app.route('/api/clients', methods=['POST'])
def create_client():
    try:
        data = request.json or {}
        data['Type'] = 'client'
        client = storage.create_record(data)
        return jsonify(client.to_dict()), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Failed to create client: {str(e)}"}), 500


@app.route('/api/clients/<int:client_id>', methods=['GET'])
def get_client(client_id):
    client = storage.read_record(client_id, 'client')
    if client:
        return jsonify(client.to_dict())
    return jsonify({"error": f"Client with ID {client_id} not found"}), 404


@app.route('/api/clients/<int:client_id>', methods=['PUT'])
def update_client(client_id):
    try:
        data = request.json or {}
        if storage.update_record(client_id, data):
            updated = storage.read_record(client_id, 'client')
            return jsonify({
                "message": f"Client {client_id} updated successfully",
                "client": updated.to_dict() if updated else None
            })
        return jsonify({"error": f"Client with ID {client_id} not found"}), 404
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Failed to update client: {str(e)}"}), 500


@app.route('/api/clients/<int:client_id>', methods=['DELETE'])
def delete_client(client_id):
    if storage.delete_record(client_id, 'client'):
        return jsonify({"message": f"Client {client_id} deleted successfully"})
    return jsonify({"error": f"Client with ID {client_id} not found"}), 404


# ================== AIRLINES ==================

@app.route('/api/airlines', methods=['GET'])
def get_airlines():
    try:
        airlines = storage.read_all_records('airline')
        return jsonify([a.to_dict() for a in airlines])
    except Exception as e:
        return jsonify({"error": f"Failed to fetch airlines: {str(e)}"}), 500


@app.route('/api/airlines', methods=['POST'])
def create_airline():
    try:
        data = request.json or {}
        data['Type'] = 'airline'
        airline = storage.create_record(data)
        return jsonify(airline.to_dict()), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Failed to create airline: {str(e)}"}), 500


@app.route('/api/airlines/<int:airline_id>', methods=['GET'])
def get_airline(airline_id):
    airline = storage.read_record(airline_id, 'airline')
    if airline:
        return jsonify(airline.to_dict())
    return jsonify({"error": f"Airline with ID {airline_id} not found"}), 404


@app.route('/api/airlines/<int:airline_id>', methods=['PUT'])
def update_airline(airline_id):
    try:
        data = request.json or {}
        if storage.update_record(airline_id, data):
            updated = storage.read_record(airline_id, 'airline')
            return jsonify({
                "message": f"Airline {airline_id} updated successfully",
                "airline": updated.to_dict() if updated else None
            })
        return jsonify({"error": f"Airline with ID {airline_id} not found"}), 404
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Failed to update airline: {str(e)}"}), 500


@app.route('/api/airlines/<int:airline_id>', methods=['DELETE'])
def delete_airline(airline_id):
    if storage.delete_record(airline_id, 'airline'):
        return jsonify({"message": f"Airline {airline_id} deleted successfully"})
    return jsonify({"error": f"Airline with ID {airline_id} not found"}), 404


# ================== FLIGHTS ==================

@app.route('/api/flights', methods=['GET'])
def get_flights():
    try:
        flights = storage.read_all_records('flight')
        return jsonify([f.to_dict() for f in flights])
    except Exception as e:
        return jsonify({"error": f"Failed to fetch flights: {str(e)}"}), 500


@app.route('/api/flights', methods=['POST'])
def create_flight():
    try:
        data = request.json or {}
        data['Type'] = 'flight'

        client_id = data.get('Client_ID')
        airline_id = data.get('Airline_ID')

        if not client_id or not airline_id:
            return jsonify({"error": "Client_ID and Airline_ID are required"}), 400

        if not storage.read_record(client_id, 'client'):
            return jsonify({"error": f"Client with ID {client_id} not found"}), 400
        if not storage.read_record(airline_id, 'airline'):
            return jsonify({"error": f"Airline with ID {airline_id} not found"}), 400

        flight = storage.create_record(data)
        return jsonify(flight.to_dict()), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Failed to create flight: {str(e)}"}), 500


@app.route('/api/flights/<int:flight_id>', methods=['GET'])
def get_flight(flight_id):
    flight = storage.read_record(flight_id, 'flight')
    if flight:
        return jsonify(flight.to_dict())
    return jsonify({"error": f"Flight with ID {flight_id} not found"}), 404


@app.route('/api/flights/<int:flight_id>', methods=['PUT'])
def update_flight(flight_id):
    try:
        data = request.json or {}

        client_id = data.get('Client_ID')
        airline_id = data.get('Airline_ID')

        if client_id and not storage.read_record(client_id, 'client'):
            return jsonify({"error": f"Client with ID {client_id} not found"}), 400
        if airline_id and not storage.read_record(airline_id, 'airline'):
            return jsonify({"error": f"Airline with ID {airline_id} not found"}), 400

        if storage.update_record(flight_id, data):
            updated = storage.read_record(flight_id, 'flight')
            return jsonify({
                "message": f"Flight {flight_id} updated successfully",
                "flight": updated.to_dict() if updated else None
            })
        return jsonify({"error": f"Flight with ID {flight_id} not found"}), 404
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Failed to update flight: {str(e)}"}), 500


@app.route('/api/flights/<int:flight_id>', methods=['DELETE'])
def delete_flight(flight_id):
    if storage.delete_record(flight_id, 'flight'):
        return jsonify({"message": f"Flight {flight_id} deleted successfully"})
    return jsonify({"error": f"Flight with ID {flight_id} not found"}), 404


# ================== SEARCH / STATS / HEALTH ==================

@app.route('/api/search', methods=['GET'])
def search_records():
    try:
        record_type = request.args.get('type', '')
        field = request.args.get('field', 'all')
        value = request.args.get('value', '')

        if not record_type:
            return jsonify({"error": "Record type is required (type=client|airline|flight)"}), 400
        if not value:
            return jsonify({"error": "Search value is required"}), 400

        results = storage.search_records(record_type, field, value)
        return jsonify({
            "results": results,
            "count": len(results),
            "parameters": {
                "type": record_type,
                "field": field,
                "value": value
            }
        })
    except Exception as e:
        return jsonify({"error": f"Search failed: {str(e)}"}), 500


@app.route('/api/stats', methods=['GET'])
def get_stats():
    try:
        clients = storage.read_all_records('client')
        airlines = storage.read_all_records('airline')
        flights = storage.read_all_records('flight')

        total_clients = len(clients)
        total_airlines = len(airlines)
        total_flights = len(flights)

        start_cities = set()
        end_cities = set()
        for f in flights:
            d = f.to_dict()
            if 'Start City' in d:
                start_cities.add(d['Start City'])
            if 'End City' in d:
                end_cities.add(d['End City'])

        return jsonify({
            "statistics": {
                "clients": total_clients,
                "airlines": total_airlines,
                "flights": total_flights,
                "total_records": total_clients + total_airlines + total_flights
            },
            "flight_analysis": {
                "unique_start_cities": len(start_cities),
                "unique_end_cities": len(end_cities),
                "start_cities": list(start_cities),
                "end_cities": list(end_cities)
            }
        })
    except Exception as e:
        return jsonify({"error": f"Failed to get statistics: {str(e)}"}), 500


@app.route('/api/health', methods=['GET'])
def health_check():
    try:
        record_count = len(storage.records)
        file_exists = DATA_FILE.exists()
        file_size = DATA_FILE.stat().st_size if file_exists else 0

        return jsonify({
            "status": "healthy",
            "storage": {
                "connected": True,
                "record_count": record_count
            },
            "file_system": {
                "data_file": str(DATA_FILE),
                "exists": file_exists,
                "size_bytes": file_size
            },
            "system": {
                "python_version": sys.version,
                "platform": sys.platform
            }
        })
    except Exception as e:
        return jsonify({
            "status": "unhealthy",
            "error": str(e)
        }), 500


@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Endpoint not found",
        "message": "The requested endpoint does not exist."
    }), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "error": "Internal server error",
        "message": "An unexpected error occurred on the server."
    }), 500


if __name__ == '__main__':
    print("\n" + "=" * 60)
    print("RECORD MANAGEMENT SYSTEM")
    print("=" * 60)
    print("Application is running")
    print("Frontend GUI: http://localhost:5000")
    print("API Base URL: http://localhost:5000/api/")
    print("Health Check: http://localhost:5000/api/health")
    print(f"Data File: {DATA_FILE}")
    print(f"Records Loaded: {len(storage.records)}")
    print("=" * 60)
    print("\nPress Ctrl+C to stop the server\n")

    app.run(debug=True, host='0.0.0.0', port=5000)
