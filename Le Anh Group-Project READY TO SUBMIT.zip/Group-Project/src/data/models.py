from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Optional


@dataclass
class Record:
    """Base record class"""
    ID: int
    # Cho phép truyền Type vào __init__, nhưng subclass sẽ override về giá trị cố định
    Type: str = ""

    def to_dict(self) -> dict:
        """Convert record to dictionary for JSON serialization"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Record":
        """Create record from dictionary"""
        return cls(**data)

    def validate(self) -> None:
        """Validate record data"""
        if not isinstance(self.ID, int):
            raise ValueError("ID must be int")
        if self.ID <= 0:
            raise ValueError("ID must be positive integer")


@dataclass
class Client(Record):
    """Client record with address information"""
    Name: str = ""
    PhoneNumber: str = ""
    Address1: str = ""
    Address2: str = ""
    Address3: str = ""
    City: str = ""
    State: str = ""
    ZipCode: str = ""
    Country: str = ""

    def __post_init__(self):
        """Initialize after dataclass creation"""
        # Type luôn là 'client' dù input thế nào
        self.Type = "client"

        # Đảm bảo ID là int, nếu chuyển không được thì set về 0 (để validate() bắt lỗi sau)
        if not isinstance(self.ID, int):
            try:
                self.ID = int(self.ID)
            except (ValueError, TypeError):
                self.ID = 0

        # Chuẩn hóa các field string: None -> ""
        for field_name in [
            "Name", "PhoneNumber", "Address1", "Address2",
            "Address3", "City", "State", "ZipCode", "Country"
        ]:
            if getattr(self, field_name) is None:
                setattr(self, field_name, "")

    def to_dict(self) -> dict:
        """Convert to dictionary with frontend-compatible field names"""
        data = super().to_dict()
        # Map sang tên field mà frontend + test đang dùng
        return {
            'ID': data['ID'],
            'Type': data['Type'],
            'Name': data['Name'],
            'Phone Number': data['PhoneNumber'],
            'Address Line 1': data['Address1'],
            'Address Line 2': data['Address2'],
            'Address Line 3': data['Address3'],
            'City': data['City'],
            'State': data['State'],
            'Zip Code': data['ZipCode'],
            'Country': data['Country']
        }

    @classmethod
    def from_frontend_dict(cls, data: dict) -> "Client":
        """Create client from frontend dictionary format"""
        return cls(
            ID=data.get('ID', 0),
            Name=data.get('Name', ''),
            PhoneNumber=data.get('Phone Number', ''),
            Address1=data.get('Address Line 1', ''),
            Address2=data.get('Address Line 2', ''),
            Address3=data.get('Address Line 3', ''),
            City=data.get('City', ''),
            State=data.get('State', ''),
            ZipCode=data.get('Zip Code', ''),
            Country=data.get('Country', '')
        )

    @classmethod
    def from_dict(cls, data: dict) -> "Client":
        """Create from both frontend and backend dictionary formats"""
        # Frontend format
        if 'Phone Number' in data or 'Address Line 1' in data:
            return cls.from_frontend_dict(data)
        # Backend format
        return cls(
            ID=data.get('ID', 0),
            Name=data.get('Name', ''),
            PhoneNumber=data.get('PhoneNumber', ''),
            Address1=data.get('Address1', ''),
            Address2=data.get('Address2', ''),
            Address3=data.get('Address3', ''),
            City=data.get('City', ''),
            State=data.get('State', ''),
            ZipCode=data.get('ZipCode', ''),
            Country=data.get('Country', '')
        )

    def validate(self) -> None:
        """Validate client data"""
        super().validate()
        if not self.Name or not self.Name.strip():
            raise ValueError("Client name is required")
        if not self.PhoneNumber or not self.PhoneNumber.strip():
            raise ValueError("Phone number is required")
        if not self.City or not self.City.strip():
            raise ValueError("City is required")
        if not self.Country or not self.Country.strip():
            raise ValueError("Country is required")


@dataclass
class Airline(Record):
    """Airline company record"""
    CompanyName: str = ""

    def __post_init__(self):
        """Initialize after dataclass creation"""
        self.Type = "airline"
        if not isinstance(self.ID, int):
            try:
                self.ID = int(self.ID)
            except (ValueError, TypeError):
                self.ID = 0

    def to_dict(self) -> dict:
        """Convert to dictionary with frontend-compatible field names"""
        data = super().to_dict()
        return {
            'ID': data['ID'],
            'Type': data['Type'],
            'Company Name': data['CompanyName']
        }

    @classmethod
    def from_frontend_dict(cls, data: dict) -> "Airline":
        """Create airline from frontend dictionary format"""
        return cls(
            ID=data.get('ID', 0),
            CompanyName=data.get('Company Name', '')
        )

    @classmethod
    def from_dict(cls, data: dict) -> "Airline":
        """Create from both frontend and backend dictionary formats"""
        if 'Company Name' in data:
            return cls.from_frontend_dict(data)
        return cls(
            ID=data.get('ID', 0),
            CompanyName=data.get('CompanyName', '')
        )

    def validate(self) -> None:
        """Validate airline data"""
        super().validate()
        if not self.CompanyName or not self.CompanyName.strip():
            raise ValueError("Company name is required")


@dataclass
class Flight(Record):
    """Flight record linking client and airline"""
    Client_ID: int = 0
    Airline_ID: int = 0
    Date: str = ""
    StartCity: str = ""
    EndCity: str = ""

    def __post_init__(self):
        """Initialize after dataclass creation"""
        self.Type = "flight"

        # ID, Client_ID, Airline_ID luôn là int (hoặc 0 nếu lỗi)
        for attr in ["ID", "Client_ID", "Airline_ID"]:
            val = getattr(self, attr)
            if not isinstance(val, int):
                try:
                    setattr(self, attr, int(val))
                except (ValueError, TypeError):
                    setattr(self, attr, 0)

    def to_dict(self) -> dict:
        """Convert to dictionary with frontend-compatible field names"""
        data = super().to_dict()
        return {
            'ID': data['ID'],
            'Type': data['Type'],
            'Client_ID': data['Client_ID'],
            'Airline_ID': data['Airline_ID'],
            'Date': data['Date'],
            'Start City': data['StartCity'],
            'End City': data['EndCity']
        }

    @classmethod
    def from_frontend_dict(cls, data: dict) -> "Flight":
        """Create flight from frontend dictionary format"""
        return cls(
            ID=data.get('ID', 0),
            Client_ID=data.get('Client_ID', 0),
            Airline_ID=data.get('Airline_ID', 0),
            Date=data.get('Date', ''),
            StartCity=data.get('Start City', ''),
            EndCity=data.get('End City', '')
        )

    @classmethod
    def from_dict(cls, data: dict) -> "Flight":
        """Create from both frontend and backend dictionary formats"""
        if 'Start City' in data or 'End City' in data:
            return cls.from_frontend_dict(data)
        return cls(
            ID=data.get('ID', 0),
            Client_ID=data.get('Client_ID', 0),
            Airline_ID=data.get('Airline_ID', 0),
            Date=data.get('Date', ''),
            StartCity=data.get('StartCity', ''),
            EndCity=data.get('EndCity', '')
        )

    def validate(self) -> None:
        """Validate flight data"""
        super().validate()

        if self.Client_ID <= 0:
            raise ValueError("Client ID must be positive integer")
        if self.Airline_ID <= 0:
            raise ValueError("Airline ID must be positive integer")

        # Validate date
        try:
            if 'T' in self.Date:
                # datetime-local hoặc ISO
                datetime.fromisoformat(self.Date.replace('Z', '+00:00'))
            else:
                datetime.strptime(self.Date, '%Y-%m-%d')
        except (ValueError, TypeError):
            raise ValueError(f"Invalid date format: {self.Date}. Use YYYY-MM-DD or ISO format")

        if not self.StartCity or not self.StartCity.strip():
            raise ValueError("Start city is required")
        if not self.EndCity or not self.EndCity.strip():
            raise ValueError("End city is required")


# Type alias
RecordType = Client | Airline | Flight


def create_record_from_dict(data: dict) -> RecordType:
    """Factory function to create appropriate record from dictionary"""
    record_type = str(data.get('Type', '')).lower()

    if record_type == 'client':
        return Client.from_dict(data)
    elif record_type == 'airline':
        return Airline.from_dict(data)
    elif record_type == 'flight':
        return Flight.from_dict(data)
    else:
        raise ValueError(f"Unknown record type: {record_type}")


def validate_record(data: dict) -> None:
    """Validate record data before saving"""
    record = create_record_from_dict(data)
    record.validate()
