"""
File I/O and Storage Module

Handles saving and loading record data to/from a JSON file.
Keeps records in memory during the program and writes to disk on save.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import List, Dict, Any, Optional

from .models import Client, Airline, Flight, create_record_from_dict

# Mặc định lưu ở src/record/record.jsonl (tên cũ vẫn dùng, nhưng format là JSON list)
DEFAULT_RECORD_PATH = Path(__file__).resolve().parents[1] / "record" / "record.jsonl"

RecordType = Client | Airline | Flight


class RecordStorage:
    """
    In-memory storage + JSON persistence layer cho Client, Airline, Flight.
    - self.records luôn là list các instance: Client / Airline / Flight
    - File trên đĩa là một JSON array các dict (chuẩn hoá qua .to_dict())
    """

    def __init__(self, filename: str | Path | None = None) -> None:
        if filename is None:
            self.path = DEFAULT_RECORD_PATH
        else:
            self.path = Path(filename)

        # Đảm bảo thư mục tồn tại
        self.path.parent.mkdir(parents=True, exist_ok=True)

        self.records: List[RecordType] = []
        self.load_records()
        print(f"Storage initialized with {len(self.records)} records from {self.path}")

    # ------------------------------------------------------------------
    # Low-level load / save
    # ------------------------------------------------------------------
    def load_records(self) -> None:
        """
        Load records từ file.

        Hỗ trợ các format:
        1) File chưa tồn tại       -> records = []
        2) JSON list: [ {...}, {...} ]
        3) Legacy dict: {"clients":[...], "airlines":[...], "flights":[...]}
        4) Fallback JSON Lines (mỗi dòng là 1 JSON object hoặc list)

        Lưu ý:
        - KHÔNG gọi .validate() khi load, để không drop dữ liệu cũ/bị thiếu field.
        - self.records luôn là list instance (Client / Airline / Flight).
        """
        self.records = []

        if not self.path.exists():
            print(f"Data file {self.path} does not exist. Starting with empty records.")
            return

        try:
            text = self.path.read_text(encoding="utf-8").strip()
            if not text:
                print(f"Data file {self.path} is empty. Starting with empty records.")
                return

            # ----------------------------------------------------------
            # Thử parse như JSON chuẩn trước
            # ----------------------------------------------------------
            try:
                parsed = json.loads(text)
            except json.JSONDecodeError:
                parsed = None

            if parsed is not None:
                # Case 1: JSON list [ {...}, {...} ]
                if isinstance(parsed, list):
                    for idx, item in enumerate(parsed, 1):
                        if not isinstance(item, dict):
                            print(f"Warning: Skipping non-dict item at index {idx}")
                            continue
                        try:
                            # Không validate để không reject record thiếu field
                            rec = create_record_from_dict(item)
                            self.records.append(rec)
                        except ValueError as e:
                            print(f"Warning: Skipping invalid record at index {idx}: {e}")

                    print(f"Loaded {len(self.records)} records from {self.path}")
                    return

                # Case 2: legacy dict {"clients": [...], "airlines": [...], "flights": [...]}
                if isinstance(parsed, dict) and any(
                    key in parsed for key in ("clients", "airlines", "flights")
                ):
                    # clients
                    for idx, c in enumerate(parsed.get("clients", []), 1):
                        if not isinstance(c, dict):
                            print(f"Warning: Skipping non-dict client at index {idx}")
                            continue
                        try:
                            data = {"Type": "client", **c}
                            client = Client.from_dict(data)
                            # Không validate ở đây
                            self.records.append(client)
                        except Exception as e:
                            print(f"Warning: Skipping invalid client at index {idx}: {e}")

                    # airlines
                    for idx, a in enumerate(parsed.get("airlines", []), 1):
                        if not isinstance(a, dict):
                            print(f"Warning: Skipping non-dict airline at index {idx}")
                            continue
                        try:
                            data = {"Type": "airline", **a}
                            airline = Airline.from_dict(data)
                            self.records.append(airline)
                        except Exception as e:
                            print(f"Warning: Skipping invalid airline at index {idx}: {e}")

                    # flights
                    for idx, f in enumerate(parsed.get("flights", []), 1):
                        if not isinstance(f, dict):
                            print(f"Warning: Skipping non-dict flight at index {idx}")
                            continue
                        try:
                            data = {"Type": "flight", **f}
                            flight = Flight.from_dict(data)
                            self.records.append(flight)
                        except Exception as e:
                            print(f"Warning: Skipping invalid flight at index {idx}: {e}")

                    print(f"Loaded {len(self.records)} records from {self.path}")
                    return

                # Case 3: một dict đơn lẻ khác (ít gặp) → thử xem như 1 record
                if isinstance(parsed, dict):
                    try:
                        rec = create_record_from_dict(parsed)
                        self.records.append(rec)
                    except ValueError as e:
                        print(f"Warning: Skipping invalid single-record JSON: {e}")
                    print(f"Loaded {len(self.records)} records from {self.path}")
                    return

            # ----------------------------------------------------------
            # Nếu không parse được JSON chuẩn → fallback JSON Lines
            # ----------------------------------------------------------
            self.records = []
            for line_num, line in enumerate(text.splitlines(), 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError as e:
                    print(f"Warning: Skipping invalid JSON line {line_num}: {e}")
                    continue

                if isinstance(obj, list):
                    # Mỗi dòng có thể là list
                    for idx, item in enumerate(obj, 1):
                        if not isinstance(item, dict):
                            print(
                                f"Warning: Skipping non-dict item on line {line_num} index {idx}"
                            )
                            continue
                        try:
                            rec = create_record_from_dict(item)
                            self.records.append(rec)
                        except ValueError as e:
                            print(
                                f"Warning: Skipping invalid record on line {line_num} index {idx}: {e}"
                            )
                elif isinstance(obj, dict):
                    try:
                        rec = create_record_from_dict(obj)
                        self.records.append(rec)
                    except ValueError as e:
                        print(f"Warning: Skipping invalid record on line {line_num}: {e}")
                else:
                    print(f"Warning: Skipping non-dict JSON on line {line_num}")

            print(f"Loaded {len(self.records)} records from {self.path}")

        except Exception as e:
            print(f"Error loading records from {self.path}: {e}")
            self.records = []

    def save(self) -> None:
        """Save current records thành một JSON array."""
        try:
            data: List[Dict[str, Any]] = [r.to_dict() for r in self.records]
            with self.path.open("w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            print(f"Saved {len(self.records)} records to {self.path}")
        except Exception as e:
            print(f"Error saving records: {e}")
            raise

    # Backward-compat alias (nếu code nào đó gọi save_records)
    def save_records(self) -> None:
        self.save()

    # ------------------------------------------------------------------
    # ID handling
    # ------------------------------------------------------------------
    def get_next_id(self, record_type: Optional[str] = None) -> int:
        """
        Lấy ID kế tiếp.
        - Nếu record_type is None -> dùng max ID của tất cả records + 1
        - Nếu record_type cho trước -> dùng max ID của records cùng Type + 1 (hoặc 1 nếu chưa có)
        """
        if not self.records:
            return 1

        if record_type is None:
            max_id = max(r.ID for r in self.records)
            return max_id + 1

        rt = record_type.lower()
        same_type_ids = [r.ID for r in self.records if r.Type.lower() == rt]
        if not same_type_ids:
            return 1
        return max(same_type_ids) + 1

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------
    def create_record(self, record_data: Dict[str, Any]) -> RecordType:
        """
        Tạo record mới từ dict:
        - Nếu không có ID -> gán ID = get_next_id() (global sequence)
        - Trả về instance Client/Airline/Flight
        """
        # Không override ID nếu đã có (phục vụ test get_next_id_with_records)
        if not record_data.get("ID"):
            record_data["ID"] = self.get_next_id()

        record = create_record_from_dict(record_data)
        record.validate()

        self.records.append(record)
        self.save()
        return record

    def create_record_from_model(self, model: RecordType) -> RecordType:
        """
        Tạo record từ instance model, luôn cấp ID mới (bỏ qua ID cũ).
        Dùng global sequence (get_next_id()) để phục vụ test duplicate ID.
        """
        data = model.to_dict()
        data["Type"] = model.Type  # đảm bảo có Type chuẩn
        data["ID"] = self.get_next_id()

        record = create_record_from_dict(data)
        record.validate()

        self.records.append(record)
        self.save()
        return record

    def read_record(
        self, record_id: int, record_type: Optional[str] = None
    ) -> Optional[RecordType]:
        """Lấy một record theo ID, optional filter theo Type."""
        for r in self.records:
            if r.ID != record_id:
                continue
            if record_type and r.Type.lower() != record_type.lower():
                continue
            return r
        return None

    def read_all_records(self, record_type: Optional[str] = None) -> List[RecordType]:
        """Lấy toàn bộ records, optional filter theo Type."""
        if record_type is None:
            return list(self.records)
        rt = record_type.lower()
        return [r for r in self.records if r.Type.lower() == rt]

    def read_clients(self) -> List[Client]:
        return [r for r in self.records if isinstance(r, Client)]

    def read_airlines(self) -> List[Airline]:
        return [r for r in self.records if isinstance(r, Airline)]

    def read_flights(self) -> List[Flight]:
        return [r for r in self.records if isinstance(r, Flight)]

    def update_record(self, record_id: int, update_data: Dict[str, Any]) -> bool:
        """
        Cập nhật record với ID tương ứng (không đổi Type và ID).
        update_data dùng field dạng "frontend" (Name, City, Phone Number, ...).
        """
        record = self.read_record(record_id)
        if record is None:
            return False

        # Lấy dict hiện tại, merge, rồi tạo lại bằng factory
        current = record.to_dict()
        current.update(update_data)

        # Đảm bảo ID + Type không bị đổi
        current["ID"] = record.ID
        current["Type"] = record.Type

        # Tạo instance mới và validate
        new_record = create_record_from_dict(current)
        new_record.validate()

        # Thay trong self.records
        for idx, r in enumerate(self.records):
            if r.ID == record_id and r.Type == record.Type:
                self.records[idx] = new_record
                break

        self.save()
        return True

    def _delete_client_flights_internal(self, client_id: int) -> int:
        """Xoá flights theo Client_ID, không save; trả về số record xoá."""
        before = len(self.records)
        self.records = [
            r for r in self.records
            if not (isinstance(r, Flight) and r.Client_ID == client_id)
        ]
        return before - len(self.records)

    def _delete_airline_flights_internal(self, airline_id: int) -> int:
        """Xoá flights theo Airline_ID, không save; trả về số record xoá."""
        before = len(self.records)
        self.records = [
            r for r in self.records
            if not (isinstance(r, Flight) and r.Airline_ID == airline_id)
        ]
        return before - len(self.records)

    def delete_record(self, record_id: int, record_type: Optional[str] = None) -> bool:
        """
        Xoá record:
        - Nếu record_type is None -> xoá mọi record có ID = record_id
        - Nếu record_type = 'client' -> xoá client + toàn bộ flights của client đó
        - Nếu record_type = 'airline' -> xoá airline + toàn bộ flights của airline đó
        """
        deleted = False

        if record_type is None:
            before = len(self.records)
            self.records = [r for r in self.records if r.ID != record_id]
            deleted = len(self.records) < before

        else:
            rt = record_type.lower()
            before = len(self.records)

            if rt == "client":
                # xoá client
                self.records = [
                    r for r in self.records
                    if not (isinstance(r, Client) and r.ID == record_id)
                ]
                if len(self.records) < before:
                    deleted = True
                # xoá luôn flights phụ thuộc
                self._delete_client_flights_internal(record_id)

            elif rt == "airline":
                # xoá airline
                self.records = [
                    r for r in self.records
                    if not (isinstance(r, Airline) and r.ID == record_id)
                ]
                if len(self.records) < before:
                    deleted = True
                # xoá luôn flights phụ thuộc
                self._delete_airline_flights_internal(record_id)

            else:
                # Type khác (vd 'flight')
                self.records = [
                    r for r in self.records
                    if not (r.ID == record_id and r.Type.lower() == rt)
                ]
                deleted = len(self.records) < before

        if deleted:
            self.save()
        return deleted

    # ------------------------------------------------------------------
    # Delete flights helpers (dùng trong test riêng)
    # ------------------------------------------------------------------
    def delete_client_flights(self, client_id: int) -> int:
        """Xoá tất cả flights của một client; trả về số flight bị xoá."""
        deleted = self._delete_client_flights_internal(client_id)
        if deleted:
            self.save()
        return deleted

    def delete_airline_flights(self, airline_id: int) -> int:
        """Xoá tất cả flights của một airline; trả về số flight bị xoá."""
        deleted = self._delete_airline_flights_internal(airline_id)
        if deleted:
            self.save()
        return deleted

    # ------------------------------------------------------------------
    # Search / utility
    # ------------------------------------------------------------------
    def search_records(self, record_type: str, field: str, value: str) -> List[Dict[str, Any]]:
        """
        Tìm kiếm records theo:
        - record_type: 'client' / 'airline' / 'flight'
        - field: tên field dạng frontend (Name, City, Country, 'all', ...)
        - value: chuỗi cần tìm (case-insensitive)
        Kết quả trả về list[dict] (dùng to_dict()).
        """
        rt = record_type.lower()
        search_value = str(value).lower().strip()
        results: List[Dict[str, Any]] = []

        for r in self.records:
            if r.Type.lower() != rt:
                continue

            data = r.to_dict()

            # search across all fields
            if field == "all":
                found = False
                for v in data.values():
                    if v is None:
                        continue
                    s = str(v).lower()
                    if search_value in s:
                        found = True
                        break
                if found:
                    results.append(data)
                continue

            # field cụ thể
            if field not in data:
                # field không tồn tại -> không crash, chỉ bỏ qua
                continue

            v = data[field]
            if v is None:
                continue

            s = str(v).lower()

            # Đặc biệt cho Name:
            # - 1 từ: giữ nguyên behavior cũ (token match) để test pass
            # - >1 từ: yêu cầu tất cả từ xuất hiện trong tokens (không cần đúng thứ tự)
            if field == "Name":
                tokens = s.replace(",", " ").split()
                words = search_value.split()

                if not words:
                    continue

                if len(words) == 1:
                    if words[0] in tokens:
                        results.append(data)
                else:
                    if all(w in tokens for w in words):
                        results.append(data)
            else:
                # các field khác: substring
                if search_value in s:
                    results.append(data)

        return results

    def advanced_search(self, **criteria: Any) -> List[RecordType]:
        """
        Advanced search trả về các instance model.
        Criteria dùng field name dạng attribute của dataclass (City, Country, State, ...).
        - advanced_search(City="New York")
        - advanced_search(Country="USA", State="NY")
        - advanced_search() -> trả về tất cả records
        """
        if not criteria:
            return list(self.records)

        results: List[RecordType] = []
        for r in self.records:
            ok = True
            for field, expected in criteria.items():
                actual = getattr(r, field, None)
                if actual != expected:
                    ok = False
                    break
            if ok:
                results.append(r)
        return results

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------
    def get_statistics(self) -> Dict[str, Any]:
        """
        Trả về thống kê:
        {
            'total_records': ...,
            'clients': ...,
            'airlines': ...,
            'flights': ...,
            'flight_cities': {
                'unique_start_cities': ...,
                'unique_end_cities': ...
            }
        }
        """
        clients = self.read_clients()
        airlines = self.read_airlines()
        flights = self.read_flights()

        start_cities = {f.StartCity for f in flights}
        end_cities = {f.EndCity for f in flights}

        return {
            "total_records": len(self.records),
            "clients": len(clients),
            "airlines": len(airlines),
            "flights": len(flights),
            "flight_cities": {
                "unique_start_cities": len(start_cities),
                "unique_end_cities": len(end_cities),
            },
        }

    # ------------------------------------------------------------------
    # Import / Export
    # ------------------------------------------------------------------
    def export_to_file(self, export_path: Path | str) -> None:
        """Export records ra một JSON array dicts."""
        export_path = Path(export_path)
        data: List[Dict[str, Any]] = [r.to_dict() for r in self.records]
        with export_path.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def import_from_file(self, import_path: Path | str, merge: bool = False) -> None:
        """
        Import records từ file JSON:
        - import_path chứa list[dict]
        - merge=False: thay thế toàn bộ records
        - merge=True: ghép thêm vào danh sách hiện tại
        """
        import_path = Path(import_path)
        with import_path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError("Import file must contain a JSON array of records")

        imported: List[RecordType] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            rec = create_record_from_dict(item)
            rec.validate()
            imported.append(rec)

        if merge:
            self.records.extend(imported)
        else:
            self.records = imported

        self.save()

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------
    def clear_all(self) -> None:
        """Xoá toàn bộ records và lưu file rỗng."""
        self.records = []
        self.save()
        print("All records cleared")


# ----------------------------------------------------------------------
# Singleton factory: get_storage used by tests
# ----------------------------------------------------------------------
_storage_instances: Dict[str, RecordStorage] = {}


def get_storage(path: str | Path | None = None) -> RecordStorage:
    """
    Trả về singleton RecordStorage cho một path nhất định.
    - Nếu path=None -> dùng DEFAULT_RECORD_PATH
    - Cùng path (sau khi resolve) -> cùng một instance
    """
    if path is None:
        storage_path = DEFAULT_RECORD_PATH
    else:
        storage_path = Path(path)

    key = str(storage_path.resolve())

    if key not in _storage_instances:
        _storage_instances[key] = RecordStorage(storage_path)

    return _storage_instances[key]
