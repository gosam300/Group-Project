# Models Package

This package contains dataclass-based models for:

- Client
- Airline
- Flight

Each model includes:
- Validation
- Serialization (`to_dict`)
- Deserialization (`from_dict`)

## Structure
```
models_package/
  src/
    models.py
  README.md
```

## Usage
Import models like:
```python
from models import Client, Airline, Flight
```
