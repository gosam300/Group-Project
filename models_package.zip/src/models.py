from dataclasses import dataclass, asdict
from datetime import datetime

@dataclass
class Client:
    ID: int
    Type: str = "client"
    Name: str = ""
    Address1: str = ""
    Address2: str = ""
    Address3: str = ""
    City: str = ""
    State: str = ""
    ZipCode: str = ""
    Country: str = ""
    PhoneNumber: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "Client":
        return Client(**d)

    def validate(self) -> None:
        if not isinstance(self.ID, int):
            raise ValueError("ID must be int")
        if self.Type.lower() != "client":
            raise ValueError("Type must be 'client'")
        if not self.Name:
            raise ValueError("Client name required")

@dataclass
class Airline:
    ID: int
    Type: str = "airline"
    CompanyName: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "Airline":
        return Airline(**d)

    def validate(self) -> None:
        if not isinstance(self.ID, int):
            raise ValueError("ID must be int")
        if self.Type.lower() != "airline":
            raise ValueError("Type must be 'airline'")
        if not self.CompanyName:
            raise ValueError("CompanyName required")

@dataclass
class Flight:
    ID: int
    Client_ID: int
    Airline_ID: int
    Date: str
    StartCity: str
    EndCity: str
    Type: str = "flight"

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "Flight":
        return Flight(**d)

    def validate(self) -> None:
        try:
            datetime.fromisoformat(self.Date)
        except ValueError:
            raise ValueError("Date must be ISO format (YYYY-MM-DD)")

        if self.Type.lower() != "flight":
            raise ValueError("Type must be 'flight'")
        if not isinstance(self.Client_ID, int):
            raise ValueError("Client_ID must be int")
        if not isinstance(self.Airline_ID, int):
            raise ValueError("Airline_ID must be int")
